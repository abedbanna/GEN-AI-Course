from django.shortcuts import render
from langchain.chat_models import ChatOpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.chains import RetrievalQA
import os
from django.shortcuts import render
import pinecone
from langchain.vectorstores import Pinecone

pinecone.init(
    api_key="27ad872d-0cb7-4c7d-9a1d-ebe6f93a0c2f",
    environment="gcp-starter"

)
os.environ["OPENAI_API_KEY"] = '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'

embedding = OpenAIEmbeddings(model="text-embedding-ada-002")
vectorstore = Pinecone.from_existing_index("test", embedding)
def load_vector_store():


    # retriever = vectorstore.as_retriever()
    retriever = vectorstore.as_retriever(search_type="similarity", search_kwargs={"k": 5})

    return retriever


def retrieval(question):

    template = """/
    your role is bid manager,you will extract response  from given context given in  source document, you are creative persona and expert in suadi laws for bids 
     answer in arabic language the given question in professional bussiness
    language  start your asnwer with شكرا على السؤال  وفقا لنموذج كراسة الشروط و المواصفاتif you  don't know answer " لا استطيع  الاجابة على السؤال "

    Question: {question}
    context:{context} 
    Answer
    
    """

    PROMPT = PromptTemplate(template=template,input_variables=['question','context'])


    llm = ChatOpenAI(temperature=0.9, model_name="gpt-4")


    #
    qa_chain = RetrievalQA.from_chain_type(
        llm,
        chain_type="stuff",
        retriever=load_vector_store(),
        # return_source_documents=True
        chain_type_kwargs={"prompt": PROMPT}
    )
    ask = qa_chain({"query": question})
    return ask


def index(request):

    if request.method == 'POST':

        # Adding new parameter to
        question = request.POST.get('txtequestion', '')

        # Passing values along with value for new parameter


        response= retrieval(question)

    else:
        question = "  علي  ماذا تحتوي الكراسة"
        response= {
            "query":question
        }


    # processed_text = customer_feedback(customer_language,chat_text)
    context={
        # 'response':processed_text.replace("```",''),
        'response':response,


    }
    # Pass the processed text to the template for rendering
    return render(request, context=context, template_name='index.html')