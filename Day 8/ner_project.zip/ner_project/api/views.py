from rest_framework.decorators import api_view
from rest_framework.response import Response
from transformers import pipeline

@api_view(['GET'])
def ner_task(request):
    if request.method == 'GET':
        # Load the text generation pipeline
        ner_model = pipeline("ner",'abedbanna/xlm-roberta-base-finetuned-panx-ar',token="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")
        prompt = request.GET.get('prompt')

        # Generate text using the pipeline
        response = ner_model(prompt)

        # Return the generated text as a JSON response
        return Response({'response': response})
    else:
        return Response({'error': 'Invalid request method'})
